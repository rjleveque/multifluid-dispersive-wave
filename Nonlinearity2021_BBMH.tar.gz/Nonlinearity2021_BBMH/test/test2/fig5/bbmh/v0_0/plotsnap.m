function plotsnap(m,j)  
fid = fopen('fort.c0000');
%
data0 = fscanf(fid,'%g',[4 inf]);
status = fclose(fid);
data0 = data0';
%
clf
n1 = j+10000;
fname = ['fort.',num2str(n1)];
fname(6) = 't';
fid  = fopen(fname);
t1   = fscanf(fid,'%g',1);        fscanf(fid,'%s',1);
meqn = fscanf(fid,'%d',1);      fscanf(fid,'%s',1);
ngrids = fscanf(fid,'%d',1);    fscanf(fid,'%s',1);
fclose(fid);
%
fname(6) = 'c';
fid    = fopen(fname);
data1  = fscanf(fid,'%g',[4 inf]);
status = fclose(fid);
data1 = data1';
%
framest = [num2str(j)];
%
if m==1
   plot(data0(:,1),data0(:,2),'r--',...
        data1(:,1),data1(:,2),'b-',...
        'LineWidth',1) 
%
   title(['$u$ at time t=', num2str(t1),'with $v_{0} = 0$'],...
        'fontsize',20,...
        'interpreter','latex')
elseif m==2
   plot(data0(:,1),data0(:,3)*30,'r--',...
        data1(:,1),data1(:,3)*30,'b-',...
        'LineWidth',1) 
%
   title(['$v$ at time t=', num2str(t1),' with $v_{0} = 0$'],...
        'fontsize',20,...
        'interpreter','latex')
elseif m==3
   plot(data0(:,1),data0(:,4),'r--',...
        data1(:,1),data1(:,4),'b-',...
        'LineWidth',1)
%
   title(['$w$ at time t=', num2str(t1),' with $v_{0} = 0$'],...
        'fontsize',20,...
        'interpreter','latex')
end
%
xmin = min(min(data0(:,1)));
xmax = max(max(data0(:,1)));
xlim([xmin xmax])
%
legend('$t=0$','BBMH',...
       'fontsize',20,...
       'interpreter','latex',...
       'Location','NorthWest')
%
xlabel('$x$','fontsize',20,'interpreter','latex')
set(gca,'TickLabelInterpreter','latex',...
    'fontsize',20)
grid on
%
if m==1
   print -depsc test2_fig5_bbmh_v0_u
elseif m==2
   print -depsc test2_fig5_bbmh_v0_v
elseif m==3
   print -depsc test2_fig5_bbmh_v0_w
end
