function plot_bbm_bbmh(m,j)  
% BBMH: initial condition
fid = fopen('fort.c0000');
%
data0 = fscanf(fid,'%g',[4 inf]);
status = fclose(fid);
data0 = data0';
%
clf
n1 = j+10000;
fname = ['fort.',num2str(n1)];
fname(6) = 't';
fid  = fopen(fname);
t1   = fscanf(fid,'%g',1);      fscanf(fid,'%s',1);
meqn = fscanf(fid,'%d',1);      fscanf(fid,'%s',1);
ngrids = fscanf(fid,'%d',1);    fscanf(fid,'%s',1);
fclose(fid);
%
fname(6) = 'c';
fid    = fopen(fname);
data1  = fscanf(fid,'%g',[4 inf]);
status = fclose(fid);
data1 = data1';
%
fname = ['../../bbm/fort.',num2str(n1)];
fname(16) = 'c';
fid    = fopen(fname);
data2  = fscanf(fid,'%g',[3 inf]);
status = fclose(fid);
data2 = data2';
%
framest = [num2str(j)];
%
xmin  = min(min(data0(:,1)));
xmax  = max(max(data0(:,1)));
%
plot(data0(:,1),data0(:,2),'k--',...
     data2(:,1),data2(:,2),'r-',...
     data1(:,1),data1(:,2),'b-',...
     'LineWidth',1) 
%
title(['$u$ at time t=', num2str(t1),' with exact $v_{0}$'],...
      'fontsize',20,...
      'interpreter','latex')
%
legend('$t=0$','BBM','BBMH',...
      'fontsize',20,...
      'interpreter','latex',...
      'Location','NorthWest')
%
xlabel('$x$','fontsize',20,'interpreter','latex')
set(gca,'TickLabelInterpreter','latex',...
    'fontsize',20)
%
xlim([xmin xmax])
%ylim([1 3.2])
%
grid on
print -depsc test2_fig5_bbm_bbmh_vex
