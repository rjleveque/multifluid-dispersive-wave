function plotsnap(j)  
fid = fopen('fort.c0000');
%
data0 = fscanf(fid,'%g',[3 inf]);
status = fclose(fid);
data0 = data0';
%
clf
n1 = j+10000;
fname = ['fort.',num2str(n1)];
fname(6) = 't';
fid  = fopen(fname);
t1   = fscanf(fid,'%g',1);      fscanf(fid,'%s',1);
meqn = fscanf(fid,'%d',1);      fscanf(fid,'%s',1);
ngrids = fscanf(fid,'%d',1);    fscanf(fid,'%s',1);
fclose(fid);
%
fname(6) = 'c';
fid    = fopen(fname);
data1  = fscanf(fid,'%g',[3 inf]);
status = fclose(fid);
data1 = data1';
%
framest = [num2str(j)];
%
xmin  = min(min(data0(:,1)));
xmax  = max(max(data0(:,1)));
%
plot(data0(:,1),data0(:,2),'--',...
     data1(:,1),data1(:,2),'-',...
     'LineWidth',1) 
%
title(['$u$ at time t=', num2str(t1)],...
      'fontsize',20,...
      'interpreter','latex')
%
legend('$t=0$','$t=200$',...
      'fontsize',20,...
      'interpreter','latex',...
      'Location','NorthWest')
%
xlabel('x','fontsize',20,'interpreter','latex')
set(gca,'TickLabelInterpreter','latex',...
    'fontsize',20)
%
xlim([xmin xmax])
%
print -depsc bbm_test1_fig3_L100
end       
